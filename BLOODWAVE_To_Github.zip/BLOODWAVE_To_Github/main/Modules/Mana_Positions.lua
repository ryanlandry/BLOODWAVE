local M = {}

M.pos1 = {
	vmath.vector3(88,88,-0.5),
	vmath.vector3(56,56,-0.5),
	vmath.vector3(200,104,-0.5),
	vmath.vector3(72,200,-0.5),
	vmath.vector3(200,264,-0.5)
}

M.pos = {
	M.pos1
}





return M