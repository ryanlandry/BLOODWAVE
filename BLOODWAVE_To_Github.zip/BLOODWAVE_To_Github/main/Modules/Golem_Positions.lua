local M = {}



M.pos1 = {
	vmath.vector3(36,72,-0.5),
	vmath.vector3(140,88,-0.5),
	vmath.vector3(116,136,-0.5),
	vmath.vector3(68,200,-0.5),
	vmath.vector3(164,232,-0.5)
}

M.pos = {
	M.pos1
}


return M