local M = {}

M.pos1 = {
	vmath.vector3(72, 24, 0.3),
	vmath.vector3(112, 104, 0.3),
	vmath.vector3(232, 136, 0.3),
	vmath.vector3(160, 184, 0.3),
	vmath.vector3(63, 168, 0.3),
	vmath.vector3(30, 264, 0.3),
	vmath.vector3(200, 232, 0.3)
}

M.pos = {
	M.pos1
}


return M