embedded_components {
  id: "light"
  type: "sprite"
  data: "tile_set: \"/main/Tiles/Source/Grey_Brick.tilesource\"\n"
  "default_animation: \"light\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
embedded_components {
  id: "torch"
  type: "sprite"
  data: "tile_set: \"/main/Tiles/Source/Grey_Brick.tilesource\"\n"
  "default_animation: \"torch\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
